﻿using Newtonsoft.Json;
using Svt.Transport.Core.Clients;
using Svt.Transport.Core.Dtos.Clients;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace Svt.Clients.Fleets
{
    /*
    // note: most of this code should be here, should be http interface wrapper in infrastructure with global error handling.
    // these clients should be apart of a nuget package to keep all microservices in sync.
     */

    public class FleetClient : IFleetClient
    {
        private readonly IHttpClientFactory _clientFactory;
        private const string EndpointRobotsUrl = "https://60c8ed887dafc90017ffbd56.mockapi.io/robots";

        public FleetClient(IHttpClientFactory clientFactory)
        {
            _clientFactory = clientFactory;
        }

        public async Task<RobotDto[]> GetRobots()
        {
            var request = new HttpRequestMessage {
                Method = HttpMethod.Get,
                RequestUri = new Uri(EndpointRobotsUrl)
            };

            var response = await _clientFactory.CreateClient(string.Empty).SendAsync(request);
            var content = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception("some microservice exception in global handler.");
            }

            return JsonConvert.DeserializeObject<RobotDto[]>(content);
        }
    }
}
