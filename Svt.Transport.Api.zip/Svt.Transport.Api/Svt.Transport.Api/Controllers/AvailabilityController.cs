﻿using Microsoft.AspNetCore.Mvc;
using Svt.Transport.Core.Dtos.Services.Availabilities;
using Svt.Transport.Core.Services.Availabilities;
using System.Threading.Tasks;

namespace Svt.Transport.Api.Controllers
{
    //api2api = this could be a security scope if going through a gateway.
    [Route("api/robots")]
    public class AvailabilityController : Controller
    {
        private readonly IAvailabilityService _availabilityService;

        public AvailabilityController(IAvailabilityService availabilityService)
        {
            _availabilityService = availabilityService;
        }

        [HttpPost("closest")]
        public async Task<IActionResult> RebateCalculation([FromBody] RequestAvailabilityDto requestAvailabilityDto)
        {
            var response = await _availabilityService.FindClosestRobot(requestAvailabilityDto);
            return Ok(response);
        }
    }
}
