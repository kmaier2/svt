﻿namespace Svt.Transport.Core.Dtos.Clients
{
    public class RobotDto
    {
        public string RobotId { get; set; }
        public int BatteryLevel { get; set; }
        public int Y { get; set; }
        public int X { get; set; }
    }

}
