﻿using Svt.Transport.Core.Dtos.Services.Availabilities;
using System.Threading.Tasks;

namespace Svt.Transport.Core.Services.Availabilities
{
    public interface IAvailabilityService
    {
        Task<RobotAvailableDto> FindClosestRobot(RequestAvailabilityDto requestAvailabilityDto);
    }
}
