﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Svt.Transport.Services.Tests.Availabilities
{
    [TestClass]
    public class AvailabilityServiceTests
    {
        /*ran out of time for unit tests.*/
    }
}
