﻿using AutoMapper;
using Svt.Transport.Core.Clients;
using Svt.Transport.Core.Dtos.Clients;
using Svt.Transport.Core.Dtos.Services.Availabilities;
using Svt.Transport.Core.Services.Availabilities;
using Svt.Transport.Core.Static;
using System.Linq;
using System.Threading.Tasks;

namespace Svt.Transport.Services.Availabilities
{
    public class AvailabilityService : IAvailabilityService
    {
        private readonly IFleetClient _fleetClient;
        private readonly IMapper _mapper;

        public AvailabilityService(IFleetClient fleetClient,
            IMapper mapper)
        {
            _fleetClient = fleetClient;
            _mapper = mapper;
        }

        public async Task<RobotAvailableDto> FindClosestRobot(RequestAvailabilityDto requestAvailabilityDto)
        {
            var robots = await _fleetClient.GetRobots();

            //make custom generic errors with custom error handler for processing.
            if (robots.Length == 0)
                throw new System.Exception("no robots available");

            var robotsWithDistance = _mapper.Map<RobotDto[], RobotDtoWithDistance[]>(robots);

            foreach (var robot in robotsWithDistance)
                robot.Distance = Formulas.Distance(robot.X, robot.Y, requestAvailabilityDto.X, requestAvailabilityDto.Y);

            var clostestByDistance = robotsWithDistance
                .OrderBy(x => x.Distance)
                .First();

            var closestWithHighestBattery = robotsWithDistance
                .Where(x => x.Distance == clostestByDistance.Distance)
                .OrderByDescending(x => x.BatteryLevel)
                .First();

            return _mapper.Map<RobotAvailableDto>(closestWithHighestBattery);
        }
    }
}
