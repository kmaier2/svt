﻿using Svt.Transport.Core.Dtos.Clients;

namespace Svt.Transport.Core.Dtos.Services.Availabilities
{
    public class RobotDtoWithDistance : RobotDto
    {
        public double Distance { get; set; }
    }
}
