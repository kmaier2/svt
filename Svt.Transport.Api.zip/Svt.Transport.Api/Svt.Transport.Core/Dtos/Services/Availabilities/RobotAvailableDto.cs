﻿namespace Svt.Transport.Core.Dtos.Services.Availabilities
{
    public class RobotAvailableDto
    {
        public int RobotId { get; set; }
        public decimal DistanceToGoal { get; set; }
        public decimal BatteryLevel { get; set; }
    }
}