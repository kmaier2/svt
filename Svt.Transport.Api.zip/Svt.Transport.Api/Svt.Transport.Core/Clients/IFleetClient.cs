﻿using Svt.Transport.Core.Dtos.Clients;
using System.Threading.Tasks;

namespace Svt.Transport.Core.Clients
{
    public interface IFleetClient
    {
        Task<RobotDto[]> GetRobots();
    }
}
