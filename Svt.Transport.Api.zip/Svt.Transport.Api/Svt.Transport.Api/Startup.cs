using AutoMapper;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Svt.Clients.Fleets;
using Svt.Transport.Core.Clients;
using Svt.Transport.Core.Services.Availabilities;
using Svt.Transport.Services.Automapper;
using Svt.Transport.Services.Availabilities;

namespace Svt.Transport.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddHttpContextAccessor();
            services.AddHttpClient(string.Empty, c =>
            {
                c.Timeout = System.TimeSpan.FromSeconds(120);
            });

            services.AddScoped<IAvailabilityService, AvailabilityService>();


            services.AddScoped<IFleetClient, FleetClient>();
            Mapper.Initialize(cfg => {
                cfg.AddProfile<ServiceDtoMap>();
                cfg.ForAllMaps((obj, cnfg) => cnfg.ForAllMembers(opts => opts.Condition((src, dest, srcMember) => srcMember != null)));
            });

            services.AddSingleton(Mapper.Configuration);
            services.AddSingleton<IMapper>(sp => new Mapper(sp.GetRequiredService<AutoMapper.IConfigurationProvider>(), sp.GetService));

            services.AddControllers();

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "Svt Transportation Api", Version = "v1" });
                c.CustomSchemaIds(schema => schema.FullName);
            });

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger();


            app.UseSwaggerUI(setup =>
            {
                setup.SwaggerEndpoint("/swagger/v1/swagger.json", "Svt.Transport.Api");
                setup.RoutePrefix = "help";
                setup.DefaultModelsExpandDepth(-1);
            });

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
