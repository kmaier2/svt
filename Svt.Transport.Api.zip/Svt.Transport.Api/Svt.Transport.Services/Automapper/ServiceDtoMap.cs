﻿using AutoMapper;
using Svt.Transport.Core.Dtos.Clients;
using Svt.Transport.Core.Dtos.Services.Availabilities;

namespace Svt.Transport.Services.Automapper
{
    public class ServiceDtoMap : Profile
    {
        public ServiceDtoMap()
        {
            CreateMap<RobotDto, RobotDtoWithDistance>();
            CreateMap<RobotDtoWithDistance, RobotAvailableDto>();
        }
    }
}
