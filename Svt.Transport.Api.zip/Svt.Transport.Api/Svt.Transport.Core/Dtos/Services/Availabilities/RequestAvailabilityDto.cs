﻿namespace Svt.Transport.Core.Dtos.Services.Availabilities
{
    public class RequestAvailabilityDto
    {
        public int LoadId { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
    }
}
